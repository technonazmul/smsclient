<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Http;

use Illuminate\Http\Request;

class MessageController extends Controller
{
    public function sendmessage(Request $request,$api_key,$mobile_no,$message_content)
    {

    	$message_content = urldecode($message_content);

    	$response = Http::post("https://sms.bicitra.com/api/send?key=61115e594db42c72c693e65dbea193330f423195", [
		    'phone' => $mobile_no,
		    'message' => $message_content,
		]);

		echo $response;

    }
}
